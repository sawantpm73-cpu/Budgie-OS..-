# BudgieOS Pro Ultimate — ISO Builder

This is a fresh, GitHub-ready source project for building a bootable **amd64 Debian live ISO**.

**Important:** this ZIP is the source project and ISO builder, not the finished ISO. GitHub Actions builds the ISO and attaches it to a workflow run as an artifact.

## Easiest build route (browser)

1. Create or open a GitHub repository.
2. Upload the contents of this ZIP (the files inside `BudgieOS-Pro-Ultimate`, not the outer ZIP).
3. Open the repository's **Actions** tab.
4. Select **Build BudgieOS ISO** on the left.
5. Press **Run workflow** → **Run workflow**.
6. Wait for the job to finish successfully.
7. Open the completed workflow run. Under **Artifacts**, download `BudgieOS-Pro-Ultimate-ISO`.

The ISO is built for **64-bit x86 PCs**. Test it in a virtual machine first, or use a USB-writing tool to create installation media. Back up important files before installing any operating system.

## What's included

- Debian stable base with XFCE desktop
- Firefox ESR, LibreOffice, VLC, file manager and system utilities
- Flatpak support
- BudgieOS-themed wallpaper, desktop shortcuts and welcome helper
- GitHub Actions workflow to build and upload the ISO artifact

## Notes

- The desktop is XFCE with BudgieOS branding; this build does **not** claim to be the upstream Budgie desktop environment.
- Chrome, Microsoft 365 desktop apps, Steam, Roblox and Windows applications are not bundled. Web apps and supported Linux applications can be added later.
- The ISO builder needs internet access and several gigabytes of free build space.
